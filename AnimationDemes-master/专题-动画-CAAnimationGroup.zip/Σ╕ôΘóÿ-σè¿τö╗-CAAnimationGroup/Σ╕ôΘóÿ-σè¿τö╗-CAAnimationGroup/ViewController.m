//
//  ViewController.m
//  专题-动画-CAAnimationGroup
//
//  Created by 王博 on 16/3/15.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) UIView * redview;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView * redview = [[UIView alloc] initWithFrame:CGRectMake(50, 100, 80, 80)];
    redview.backgroundColor = [UIColor redColor];
    [self.view addSubview:redview];
    self.redview = redview;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    // 1.创建旋转动画对象
    CABasicAnimation * rotate = [CABasicAnimation animation];
    rotate.keyPath = @"transform.rotation";
    rotate.toValue = @(M_PI);
    
    // 2.创建缩放动画
    CABasicAnimation * scale = [CABasicAnimation animation];
    scale.keyPath = @"transform.scale";
    scale.toValue = @(0.0);
    
    // 3.平移动画
    CABasicAnimation * move = [CABasicAnimation animation];
    move.keyPath = @"position";
    move.toValue = [NSValue valueWithCGPoint:CGPointMake(100, 200)];
    
    // 4.将动画放到动画组
    CAAnimationGroup * group = [CAAnimationGroup animation];
    group.animations = @[rotate,scale,move];
    
    group.duration = 2.0f;
    group.removedOnCompletion = NO;
    group.fillMode = kCAFillModeForwards;
    
    [self.redview.layer addAnimation:group forKey:nil];
}

@end
