//
//  ViewController.m
//  专题-动画-3-帧动画
//
//  Created by 王博 on 16/3/14.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) UIImageView * imageView;
@property (strong,nonatomic) NSMutableArray * array;
@end

@implementation ViewController

- (NSMutableArray *)array
{
    if (_array == nil) {
        _array = [NSMutableArray array];
        for (int i = 0; i < 26; i++) {
            NSString * path = [NSBundle mainBundle].bundlePath;
            
            // 引出一个问题 png 和 JPG 格式图片加载的区别
            path = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"angry_%02d.jpg",i]];
            
            // imageWithContentOfFile:和 imageWithName:的区别
            UIImage * image = [UIImage imageWithContentsOfFile:path];
            [_array addObject:image];
        }
    }
    return _array;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView * imageView = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    imageView.image = [UIImage imageNamed:@"angry_00.jpg"];
    self.imageView = imageView;
    [self.view addSubview:self.imageView];
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (self.imageView.isAnimating) return;
    NSTimeInterval time = self.array.count * 0.075;
    self.imageView.animationImages = self.array;
    self.imageView.animationDuration = time;
    self.imageView.animationRepeatCount = 1;
    [self.imageView startAnimating];
    [self.imageView performSelector:@selector(setAnimationImages:) withObject:nil afterDelay:time];
}
@end
