//
//  ViewController.m
//  专题-动画-4-过渡动画
//
//  Created by 王博 on 16/3/14.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) UIView * someView;
@property (strong,nonatomic) UIView * view1;
@property (strong,nonatomic) UIView * view2;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.someView = [[UIView alloc] initWithFrame:CGRectMake(20, 40, 100, 100)];
    self.someView.backgroundColor = [UIColor greenColor];
    [self.view addSubview:self.someView];
    
    _view1 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)];
    _view1.backgroundColor = [UIColor redColor];
    _view1.alpha = 0;
    [self.someView addSubview:_view1];
    
    _view2 = [[UIView alloc] initWithFrame:CGRectMake(50, 50, 50, 50)];
    _view2.backgroundColor = [UIColor blueColor];
    [self.someView addSubview:_view2];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [UIView transitionWithView:self.someView duration:2.5 options:
     UIViewAnimationOptionTransitionFlipFromBottom   animations:^{
        _view2.alpha = 0;
        self.someView.center = CGPointMake(200, 400);
        _view1.alpha = 1;
    } completion:^(BOOL finished) {
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
