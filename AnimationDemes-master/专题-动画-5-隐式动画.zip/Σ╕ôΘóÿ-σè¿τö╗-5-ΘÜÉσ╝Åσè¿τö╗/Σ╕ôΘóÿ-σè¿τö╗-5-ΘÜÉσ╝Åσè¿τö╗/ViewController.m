//
//  ViewController.m
//  专题-动画-5-隐式动画
//
//  Created by 王博 on 16/3/14.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) CALayer * layer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    CALayer * layer = [CALayer layer];
    layer.frame = CGRectMake(50, 50, 80, 80);
    layer.backgroundColor = [UIColor redColor].CGColor;
    [self.view.layer addSublayer:layer];
    self.layer = layer;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    // 开启事务
    [CATransaction begin];
    // 设置可以进行动画
    [CATransaction setDisableActions:YES];
    // 设置 calayer 背景色
    self.layer.backgroundColor = [UIColor greenColor].CGColor;
    // 更改尺寸
    self.layer.frame = CGRectMake(200, 200, 100, 100);
    self.layer.opacity = 0.5;
    [CATransaction commit];
}

@end
