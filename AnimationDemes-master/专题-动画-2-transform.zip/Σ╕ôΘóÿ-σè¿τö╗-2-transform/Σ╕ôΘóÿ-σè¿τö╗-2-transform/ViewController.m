//
//  ViewController.m
//  专题-动画-2-transform
//
//  Created by 王博 on 16/3/14.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) UIButton * button;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIButton * button = [[UIButton alloc] initWithFrame:CGRectMake(100, 50, 80, 80)];
    button.backgroundColor = [UIColor redColor];
    [self.view addSubview:button];
    self.button = button;
    [button addTarget:self action:@selector(move) forControlEvents:UIControlEventTouchUpInside];
}

- (void)move{
    
    [UIView animateWithDuration:2.0 animations:^{
        // 位置移动
        [self.button setTransform:CGAffineTransformMakeTranslation(100, 300)];
        
        // 缩放，在上一次 transform 的基础上进行的操作
        [self.button setTransform:CGAffineTransformScale(self.button.transform, 1.5, 1.5)];
        
        // 旋转，也是在上一次的基础上进行的操作
        [self.button setTransform:CGAffineTransformRotate(self.button.transform, 2.0f)];
    } completion:^(BOOL finished){
        
        // 重新回到原始的状态
        self.button.transform = CGAffineTransformIdentity;
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
