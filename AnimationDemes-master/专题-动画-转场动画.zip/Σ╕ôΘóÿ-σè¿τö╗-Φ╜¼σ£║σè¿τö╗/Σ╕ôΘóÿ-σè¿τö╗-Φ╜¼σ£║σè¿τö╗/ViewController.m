//
//  ViewController.m
//  专题-动画-转场动画
//
//  Created by 王博 on 16/3/15.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic, assign) int index;
@end

@implementation ViewController
- (IBAction)prebtn:(id)sender {
    self.index--;
    if (self.index == -1) {
        self.index = 8;
    }
    
    NSString * filename = [NSString stringWithFormat:@"%d.jpg", self.index + 1];
    self.imageView.image = [UIImage imageNamed:filename];
    CATransition * anim = [CATransition animation];
    
    anim.type= @"cube";
    anim.subtype = kCATransitionFromLeft;
    anim.duration = 0.5;
    [self.view.layer addAnimation:anim forKey:nil];
    
}
- (IBAction)nextbtn:(id)sender {
    self.index++;
    if (self.index == 9) {
        self.index = 0;
    }
    NSString * filename = [NSString stringWithFormat:@"%d.jpg",self.index+1];
    self.imageView.image = [UIImage imageNamed:filename];
    CATransition * anim = [CATransition animation];
    
    // 设置过渡类型
    anim.type = @"cube";
    // 设置过渡方向
    anim.subtype = kCATransitionFromRight;
    anim.duration = 0.5;
    [self.view.layer addAnimation:anim forKey:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
