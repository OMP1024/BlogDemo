//
//  ViewController.m
//  专题-动画-CAKeyframeAnimation
//
//  Created by 王博 on 16/3/15.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) UIView * redView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIView * redView = [[UIView alloc] initWithFrame:CGRectMake(50, 50, 80, 80)];
    redView.backgroundColor = [UIColor redColor];
    [self.view addSubview:redView];
    
    self.redView = redView;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    [self test1];
    [self test2];
}

// 设置定点的运动
- (void)test2
{
    // 1.创建动画对象
    CAKeyframeAnimation * anim = [CAKeyframeAnimation animation];
    
    // 2.设置动画
    anim.keyPath = @"position";
    NSValue *v1 = [NSValue valueWithCGPoint:CGPointZero];
    NSValue *v2 = [NSValue valueWithCGPoint:CGPointMake(100, 0)];
    NSValue *v3 = [NSValue valueWithCGPoint:CGPointMake(100, 200)];
    NSValue *v4 = [NSValue valueWithCGPoint:CGPointMake(0, 200)];
    anim.values = @[v1,v2,v3,v4];

    anim.duration = 2.0f;
    anim.removedOnCompletion = NO;
    anim.fillMode = kCAFillModeForwards;
    
    // 3.添加动画
    [self.redView.layer addAnimation:anim forKey:nil];
    
}

// 按照所画的轨迹进行运动
-(void)test1
{
    // 1.创建动画对象
    CAKeyframeAnimation * anim = [CAKeyframeAnimation animation];
    
    // 2.设置动画属性
    anim.keyPath = @"position";
    
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddEllipseInRect(path, NULL, CGRectMake(100, 100, 200, 200));
    anim.path = path;
    CGPathRelease(path);
    
    // 动画的执行节奏
    anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    anim.duration = 2.0f;
    anim.removedOnCompletion = NO;
    anim.fillMode = kCAFillModeForwards;
    anim.delegate = self;
    [self.redView.layer addAnimation:anim forKey:nil];

}
#pragma mark - 监听动画的执行过程
- (void)animationDidStart:(CAAnimation *)anim
{
    NSLog(@"动画开始");
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
{
    NSLog(@"动画停止");
}

@end
