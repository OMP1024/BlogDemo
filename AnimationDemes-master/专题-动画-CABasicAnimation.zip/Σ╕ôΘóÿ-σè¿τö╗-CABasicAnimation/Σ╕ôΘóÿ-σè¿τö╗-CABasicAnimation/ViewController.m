//
//  ViewController.m
//  专题-动画-CABasicAnimation
//
//  Created by 王博 on 16/3/15.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

// later equals never
typedef NS_ENUM(NSUInteger,AnimationType){
    kAnimationScale,
    kAnimationRotate,
    kAnimationTranslate
};

@interface ViewController ()
@property (strong,nonatomic) CALayer * layer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CALayer * layer = [CALayer layer];
    layer.frame = CGRectMake(50, 50, 80, 80);
    layer.backgroundColor = [UIColor redColor].CGColor;
    [self.view.layer addSublayer:layer];
    self.layer = layer;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
//    [self testAnimation:kAnimationRotate];
//    [self testAnimation:kAnimationTranslate];
    [self testAnimation:kAnimationScale];
}

- (void)testAnimation:(AnimationType) type
{
    // 1.创建动画对象
    CABasicAnimation * animation = [CABasicAnimation animation];
    
    // 2.设置动画属性
    switch (type) {
        case kAnimationScale:
            // keyPath 决定执行怎样的动画，调整那个属性来执行动画，
            // 缩放动画
            animation.keyPath = @"bounds";
            animation.toValue = [NSValue valueWithCGRect:CGRectMake(0, 0, 150, 150)];
            break;
        case kAnimationRotate:
            // 旋转动画
            animation.keyPath = @"transform";
            animation.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeRotation(M_PI, 1, 1, 0)];
            break;
        case kAnimationTranslate:
            // 平移动画
            animation.keyPath = @"position";
            animation.toValue = [NSValue valueWithCGPoint:CGPointMake(100, 400)];
        default:
            break;
    }
    animation.duration = 2.f;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    
    // 3.添加动画
    [self.layer addAnimation:animation forKey:nil];
}



@end
