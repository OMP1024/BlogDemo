//
//  ViewController.m
//  专题-动画-1-frame
//
//  Created by 王博 on 16/3/14.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (strong,nonatomic) UIButton * button;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 简单位移和缩放动画
    UIButton * button = [[UIButton alloc] initWithFrame:CGRectMake(50, 100, 80, 80)];
    button.backgroundColor = [UIColor redColor];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(move) forControlEvents:UIControlEventTouchUpInside];
    self.button = button;
}

- (void)move
{
    // 2.0s之内完成动画
    [UIView animateWithDuration:2.0 animations:^{
        CGRect frame = CGRectMake(100, 200, 120, 120);
        self.button.frame = frame;
        self.button.backgroundColor = [UIColor greenColor];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
