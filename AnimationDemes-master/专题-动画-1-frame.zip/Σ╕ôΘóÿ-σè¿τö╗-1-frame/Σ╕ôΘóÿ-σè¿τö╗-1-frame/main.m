//
//  main.m
//  专题-动画-1-frame
//
//  Created by 王博 on 16/3/14.
//  Copyright © 2016年 304studioSwift. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
